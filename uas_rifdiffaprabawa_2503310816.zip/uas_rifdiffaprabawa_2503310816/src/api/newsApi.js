const BASE_URL = 'https://fakenews.squirro.com/news'

/**
 * Fetch a page of news articles from a given section.
 * @param {string} section - e.g. "sport", "finance", "technology"
 * @param {number} since - pagination cursor returned by the API as "next"
 * @param {number} count - how many articles to request
 * @returns {Promise<{news: Array, count: number, next: number, eof: boolean}>}
 */
export async function fetchNews(section = 'sport', since = 0, count = 12) {
  const url = `${BASE_URL}/${section}?since=${since}&count=${count}`
  const response = await fetch(url)

  if (!response.ok) {
    throw new Error(`Gagal mengambil data berita (status ${response.status})`)
  }

  const data = await response.json()
  return data
}
