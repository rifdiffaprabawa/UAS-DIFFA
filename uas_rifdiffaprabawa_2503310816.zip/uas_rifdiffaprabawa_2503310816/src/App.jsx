import React, { useEffect, useMemo, useState } from 'react'
import Navbar from './components/Navbar.jsx'
import Footer from './components/Footer.jsx'
import SearchBar from './components/SearchBar.jsx'
import NewsCard from './components/NewsCard.jsx'
import NewsModal from './components/NewsModal.jsx'
import Loader from './components/Loader.jsx'
import { fetchNews } from './api/newsApi.js'

const SECTION = 'sport'
const PAGE_SIZE = 12

export default function App() {
  const [articles, setArticles] = useState([])
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [error, setError] = useState(null)
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState(null)
  const [cursor, setCursor] = useState(0)
  const [eof, setEof] = useState(false)

  async function loadInitial() {
    setLoading(true)
    setError(null)
    try {
      const data = await fetchNews(SECTION, 0, PAGE_SIZE)
      setArticles(data.news || [])
      setCursor(data.next ?? 0)
      setEof(Boolean(data.eof))
    } catch (err) {
      setError(err.message || 'Terjadi kesalahan saat memuat berita')
    } finally {
      setLoading(false)
    }
  }

  async function loadMore() {
    if (eof || loadingMore) return
    setLoadingMore(true)
    try {
      const data = await fetchNews(SECTION, cursor, PAGE_SIZE)
      setArticles((prev) => [...prev, ...(data.news || [])])
      setCursor(data.next ?? cursor)
      setEof(Boolean(data.eof))
    } catch (err) {
      setError(err.message || 'Gagal memuat berita tambahan')
    } finally {
      setLoadingMore(false)
    }
  }

  useEffect(() => {
    loadInitial()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return articles
    return articles.filter(
      (a) =>
        a.headline.toLowerCase().includes(q) ||
        a.abstract.toLowerCase().includes(q) ||
        a.author.toLowerCase().includes(q)
    )
  }, [articles, query])

  const featured = !query && filtered.length > 0 ? filtered[0] : null
  const rest = featured ? filtered.slice(1) : filtered

  return (
    <div className="min-h-screen flex flex-col bg-cream">
      <Navbar />

      <main id="beranda" className="flex-1">
        {/* Hero */}
        <section className="bg-navy text-cream">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 py-14 sm:py-20">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-amber mb-4">
              Live Feed &middot; Section: {SECTION}
            </p>
            <h1 className="font-display font-semibold text-3xl sm:text-5xl leading-tight max-w-2xl">
              Berita olahraga, langsung dari lapangan redaksi.
            </h1>
            <p className="mt-4 max-w-xl text-cream/70 leading-relaxed">
              Wire/Sport menampilkan feed berita olahraga terbaru yang diambil langsung
              dari Fake News API, lengkap dengan fitur pencarian untuk menyaring
              judul, ringkasan, atau nama penulis.
            </p>
          </div>
        </section>

        {/* Feed */}
        <section id="feed" className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-10">
            <div>
              <h2 className="font-display font-semibold text-2xl text-navy">Feed Terbaru</h2>
              <p className="text-sm text-charcoal/60 mt-1">
                {loading ? 'Mengambil data...' : `${filtered.length} berita ditemukan`}
              </p>
            </div>
            <SearchBar value={query} onChange={setQuery} />
          </div>

          {loading && <Loader />}

          {!loading && error && (
            <div className="text-center py-16 bg-white rounded-2xl border border-coral/20">
              <p className="font-semibold text-coral mb-2">Gagal memuat berita</p>
              <p className="text-sm text-charcoal/60 mb-4">{error}</p>
              <button
                onClick={loadInitial}
                className="rounded-full bg-navy text-cream px-5 py-2 text-sm font-semibold hover:bg-navy-light transition-colors"
              >
                Coba lagi
              </button>
            </div>
          )}

          {!loading && !error && filtered.length === 0 && (
            <div className="text-center py-16 bg-white rounded-2xl border border-navy/10">
              <p className="font-display text-lg text-navy mb-1">Tidak ada hasil</p>
              <p className="text-sm text-charcoal/60">
                Coba kata kunci lain, seperti nama penulis atau bagian dari judul berita.
              </p>
            </div>
          )}

          {!loading && !error && filtered.length > 0 && (
            <>
              {featured && (
                <button
                  onClick={() => setSelected(featured)}
                  className="w-full text-left mb-10 group block bg-navy rounded-2xl overflow-hidden focus-ring"
                >
                  <div className="px-6 sm:px-10 py-10 sm:py-14 flex flex-col sm:flex-row sm:items-end gap-6 sm:gap-10">
                    <span className="shrink-0 flex items-center justify-center w-16 h-16 rounded-full bg-amber text-navy font-mono font-bold text-lg">
                      {String(featured.id).padStart(2, '0')}
                    </span>
                    <div>
                      <span className="font-mono text-[11px] uppercase tracking-widest text-teal-light">
                        Headline Utama
                      </span>
                      <h3 className="font-display font-semibold text-xl sm:text-3xl text-cream mt-2 mb-3 group-hover:text-amber transition-colors">
                        {featured.headline}
                      </h3>
                      <p className="text-cream/70 text-sm sm:text-base max-w-2xl line-clamp-2">
                        {featured.abstract}
                      </p>
                    </div>
                  </div>
                </button>
              )}

              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {rest.map((article) => (
                  <NewsCard key={article.id} article={article} onOpen={setSelected} />
                ))}
              </div>

              {!query && !eof && (
                <div className="flex justify-center mt-12">
                  <button
                    onClick={loadMore}
                    disabled={loadingMore}
                    className="rounded-full border-2 border-navy text-navy font-semibold text-sm px-6 py-3 hover:bg-navy hover:text-cream transition-colors disabled:opacity-50 focus-ring"
                  >
                    {loadingMore ? 'Memuat...' : 'Muat lebih banyak'}
                  </button>
                </div>
              )}
            </>
          )}
        </section>
      </main>

      <Footer />

      {selected && <NewsModal article={selected} onClose={() => setSelected(null)} />}
    </div>
  )
}
