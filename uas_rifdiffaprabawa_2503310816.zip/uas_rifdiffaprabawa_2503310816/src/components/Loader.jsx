import React from 'react'

export default function Loader({ label = 'Memuat berita...' }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-4">
      <div className="flex gap-1.5">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="w-3 h-3 rounded-full bg-amber animate-bounce"
            style={{ animationDelay: `${i * 0.15}s` }}
          />
        ))}
      </div>
      <p className="font-mono text-xs uppercase tracking-widest text-charcoal/50">{label}</p>
    </div>
  )
}
