import React from 'react'

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer id="tentang" className="bg-navy-dark text-cream/80 mt-24">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 grid gap-10 sm:grid-cols-3">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <span className="flex items-center justify-center w-8 h-8 rounded-full bg-amber text-navy font-mono font-bold text-xs">
              09
            </span>
            <span className="font-display font-semibold text-lg text-cream">
              Wire<span className="text-amber">/</span>Sport
            </span>
          </div>
          <p className="text-sm leading-relaxed max-w-xs">
            Feed berita olahraga yang ditampilkan langsung dari Fake News API,
            dibuat untuk kebutuhan Ujian Akhir Semester mata kuliah pemrograman web.
          </p>
        </div>

        <div>
          <h3 className="font-mono text-xs uppercase tracking-widest text-amber mb-3">Sumber Data</h3>
          <ul className="space-y-2 text-sm">
            <li>
              <a
                href="https://fakenews.squirro.com/news/sport"
                target="_blank"
                rel="noreferrer"
                className="hover:text-amber transition-colors underline decoration-cream/30 underline-offset-4"
              >
                Fake News API — Sport
              </a>
            </li>
            <li>Disediakan oleh Squirro Academy</li>
            <li>Data bersifat fiktif, hanya untuk latihan</li>
          </ul>
        </div>

        <div>
          <h3 className="font-mono text-xs uppercase tracking-widest text-amber mb-3">Proyek</h3>
          <ul className="space-y-2 text-sm">
            <li>React + Vite + Tailwind CSS</li>
            <li>Rif Diffa Prabawa</li>
            <li>NIM 2503310816</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-cream/10">
        <p className="max-w-6xl mx-auto px-4 sm:px-6 py-4 text-xs font-mono text-cream/50">
          © {year} Wire/Sport. Dibuat untuk keperluan UAS — bukan situs berita resmi.
        </p>
      </div>
    </footer>
  )
}
