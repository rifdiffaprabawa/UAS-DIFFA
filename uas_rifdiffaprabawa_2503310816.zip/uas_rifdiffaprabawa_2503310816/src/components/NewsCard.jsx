import React from 'react'

function formatDate(dateStr) {
  try {
    return new Date(dateStr).toLocaleDateString('id-ID', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    })
  } catch {
    return dateStr
  }
}

export default function NewsCard({ article, onOpen }) {
  return (
    <article className="group flex flex-col bg-white rounded-2xl border border-navy/10 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden">
      <div className="flex items-center justify-between px-5 pt-5">
        <span className="font-mono text-[11px] uppercase tracking-widest text-teal bg-teal/10 px-2.5 py-1 rounded-full">
          {article.section}
        </span>
        <span className="flex items-center justify-center w-8 h-8 rounded-full bg-navy text-cream font-mono text-xs font-semibold shrink-0">
          {String(article.id).padStart(2, '0')}
        </span>
      </div>

      <div className="px-5 pt-3 pb-5 flex flex-col flex-1">
        <h3 className="font-display font-semibold text-lg leading-snug text-navy mb-2 group-hover:text-teal transition-colors">
          {article.headline}
        </h3>
        <p className="text-sm text-charcoal/70 leading-relaxed line-clamp-3 mb-4 flex-1">
          {article.abstract}
        </p>

        <div className="flex items-center justify-between font-mono text-[11px] uppercase tracking-wide text-charcoal/50 mb-4">
          <span>{article.author}</span>
          <span>{formatDate(article.date)}</span>
        </div>

        <button
          onClick={() => onOpen(article)}
          className="mt-auto inline-flex items-center justify-center gap-2 rounded-full border-2 border-amber text-navy font-semibold text-sm px-4 py-2 hover:bg-amber transition-colors focus-ring"
        >
          Baca selengkapnya
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>
    </article>
  )
}
