import React, { useEffect } from 'react'

function formatDate(dateStr) {
  try {
    return new Date(dateStr).toLocaleDateString('id-ID', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  } catch {
    return dateStr
  }
}

export default function NewsModal({ article, onClose }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [onClose])

  if (!article) return null

  return (
    <div
      className="fixed inset-0 z-50 flex items-start sm:items-center justify-center bg-navy-dark/70 backdrop-blur-sm p-0 sm:p-6"
      onClick={onClose}
    >
      <div
        className="bg-cream w-full sm:max-w-2xl sm:rounded-2xl max-h-full sm:max-h-[85vh] overflow-y-auto shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-navy text-cream px-6 py-4 flex items-center justify-between sm:rounded-t-2xl">
          <span className="font-mono text-[11px] uppercase tracking-widest text-amber">
            {article.section} · #{String(article.id).padStart(2, '0')}
          </span>
          <button
            onClick={onClose}
            aria-label="Tutup"
            className="p-1 text-cream/70 hover:text-amber transition-colors focus-ring rounded"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M6 6l12 12M18 6L6 18" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        <div className="px-6 py-8">
          <h2 className="font-display font-semibold text-2xl sm:text-3xl text-navy leading-tight mb-3">
            {article.headline}
          </h2>

          <div className="flex flex-wrap gap-x-4 gap-y-1 font-mono text-xs uppercase tracking-wide text-charcoal/50 mb-6 pb-6 border-b border-navy/10">
            <span>Oleh {article.author}</span>
            <span>{formatDate(article.date)}</span>
          </div>

          <div
            className="prose-article text-charcoal/90 text-[15px]"
            dangerouslySetInnerHTML={{ __html: article.body }}
          />

          <a
            href={article.article_uri}
            target="_blank"
            rel="noreferrer"
            className="mt-6 inline-flex items-center gap-2 text-teal font-semibold text-sm hover:text-teal-light transition-colors"
          >
            Lihat sumber asli
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M7 17L17 7M8 7h9v9" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </a>
        </div>
      </div>
    </div>
  )
}
