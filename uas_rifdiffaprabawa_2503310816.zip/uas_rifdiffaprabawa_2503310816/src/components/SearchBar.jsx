import React from 'react'

export default function SearchBar({ value, onChange }) {
  return (
    <div className="relative w-full max-w-xl">
      <svg
        className="absolute left-4 top-1/2 -translate-y-1/2 text-navy/40"
        width="18"
        height="18"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
      >
        <circle cx="11" cy="11" r="7" />
        <path d="M21 21l-4.3-4.3" strokeLinecap="round" />
      </svg>

      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Cari judul atau penulis berita..."
        className="w-full pl-11 pr-11 py-3 rounded-full bg-white border-2 border-navy/10 text-charcoal placeholder:text-charcoal/40 font-body focus:border-amber focus:outline-none transition-colors shadow-sm"
      />

      {value && (
        <button
          onClick={() => onChange('')}
          aria-label="Bersihkan pencarian"
          className="absolute right-4 top-1/2 -translate-y-1/2 text-navy/40 hover:text-coral transition-colors"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M6 6l12 12M18 6L6 18" strokeLinecap="round" />
          </svg>
        </button>
      )}
    </div>
  )
}
