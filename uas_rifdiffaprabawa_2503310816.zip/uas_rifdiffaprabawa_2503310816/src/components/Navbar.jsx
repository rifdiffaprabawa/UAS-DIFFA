import React, { useState } from 'react'

const LINKS = [
  { label: 'Beranda', href: '#beranda' },
  { label: 'Feed', href: '#feed' },
  { label: 'Tentang', href: '#tentang' }
]

export default function Navbar() {
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-40 bg-navy text-cream shadow-lg shadow-navy/20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          <a href="#beranda" className="flex items-center gap-3 group">
            <span className="flex items-center justify-center w-9 h-9 rounded-full bg-amber text-navy font-mono font-bold text-sm border-2 border-cream/20 group-hover:border-amber transition-colors">
              09
            </span>
            <span className="font-display font-semibold text-xl tracking-tight">
              Wire<span className="text-amber">/</span>Sport
            </span>
          </a>

          <nav className="hidden md:flex items-center gap-8">
            {LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="font-mono text-xs uppercase tracking-widest text-cream/70 hover:text-amber transition-colors focus-ring rounded"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <button
            className="md:hidden p-2 text-cream focus-ring rounded"
            onClick={() => setOpen(!open)}
            aria-label="Buka menu navigasi"
            aria-expanded={open}
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              {open ? (
                <path d="M6 6l12 12M18 6L6 18" strokeLinecap="round" />
              ) : (
                <path d="M4 7h16M4 12h16M4 17h16" strokeLinecap="round" />
              )}
            </svg>
          </button>
        </div>

        {open && (
          <nav className="md:hidden pb-4 flex flex-col gap-1">
            {LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setOpen(false)}
                className="font-mono text-xs uppercase tracking-widest text-cream/70 hover:text-amber py-2 transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>
        )}
      </div>
      <div className="h-1 bg-gradient-to-r from-amber via-coral to-teal" />
    </header>
  )
}
