# uas_rifdiffaprabawa_2503310816

Project UAS — Menampilkan data berita olahraga dari [Fake News API](https://fakenews.squirro.com/news/sport) menggunakan React, Tailwind CSS, dan Vite.

## Fitur
- Mengambil data berita dari `https://fakenews.squirro.com/news/sport` (dengan pagination via `since` & `count`)
- Fitur pencarian (search) untuk menyaring berita berdasarkan judul, ringkasan, atau penulis
- Tampilan responsif dengan Tailwind CSS
- Navbar dan Footer
- Modal detail artikel

## Cara Menjalankan

1. Install dependencies:
   ```bash
   npm install
   ```
2. Jalankan development server:
   ```bash
   npm run dev
   ```
3. Buka browser di `http://localhost:5173`

## Build untuk Produksi

```bash
npm run build
npm run preview
```

## Struktur Folder

```
src/
  api/newsApi.js        -> fungsi fetch ke Fake News API
  components/
    Navbar.jsx
    Footer.jsx
    SearchBar.jsx
    NewsCard.jsx
    NewsModal.jsx
    Loader.jsx
  App.jsx                -> komponen utama (state, layout, fetching)
  main.jsx               -> entry point React
  index.css              -> tailwind directives & base styles
```

## Catatan
Jika mengalami error CORS saat fetch ke API, jalankan proyek melalui browser modern
(Chrome/Firefox terbaru) karena API ini publik dan ditujukan untuk keperluan latihan
Squirro Academy.
