/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: '#10233B',
          light: '#16304F',
          dark: '#0A1826'
        },
        cream: '#F6F3EC',
        amber: {
          DEFAULT: '#F2A93B',
          dark: '#D98E1E'
        },
        teal: {
          DEFAULT: '#1C6E68',
          light: '#2A8B83'
        },
        coral: '#E4572E',
        charcoal: '#23262B'
      },
      fontFamily: {
        display: ['"Fraunces"', 'serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace']
      }
    }
  },
  plugins: []
}
